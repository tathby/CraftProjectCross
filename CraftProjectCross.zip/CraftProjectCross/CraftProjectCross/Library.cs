﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CraftProjectCross
{
    public class Library
    {
        public static String Input(String msg)
        {
            Console.Write(msg);
            return Console.ReadLine();
        }

        public static void Print(String msg)
        {
            Console.Write(msg);
        }
    }
}
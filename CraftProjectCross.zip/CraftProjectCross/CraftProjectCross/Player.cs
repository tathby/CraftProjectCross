﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using static CraftProjectCross.Library;

namespace CraftProjectCross
{
    public class Player
    {
        private double money;
        private List<Item>? playerItems;
        private List<Recipe>? playerRecipes;
        public String playerName = "Player One";

        public Player() 
        {
            money = 0;
            playerItems = new List<Item>();
            playerRecipes = new List<Recipe>();
            //playerName = ChangeName();
            Item bread = new Item("Bread", 2.50, 2);
            playerItems.Add(bread);
            List<Item> reqItems = new List<Item> { bread, bread };
            Recipe breadSand = new Recipe("Bread Sandwich", reqItems, 1, 5);
            //temporary^
        }

        public void About()
        {
            Print($"Player Name: {playerName}\nCurrency: " + money.ToString("c") + $"\nItems: {playerItems}\nRecipes: {playerRecipes}\n");
        }

        public void Craft()
        {
            throw new System.NotImplementedException();
        }

        public String ChangeName()
        {
            playerName = (Library.Input("Enter your username: "));
            return playerName;
        }
    }
}
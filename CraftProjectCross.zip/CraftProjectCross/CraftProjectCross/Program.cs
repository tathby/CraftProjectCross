﻿using static CraftProjectCross.Library;
using static CraftProjectCross.Engine;


namespace CraftProjectCross
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Print("Welcome to Craft!\n");
            Start();
        }

    }
}

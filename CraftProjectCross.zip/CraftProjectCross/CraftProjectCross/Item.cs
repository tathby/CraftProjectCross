﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CraftProjectCross
{
    public class Item
    {
        private String itemName = "";
        private double itemValue;
        private bool isCrafted;
        private int numItem;

       public Item(String name, double value, int num) 
        {
            isCrafted = false;
            itemName = name;
            itemValue = value;
            numItem = num;
        }

        public void itemIsCrafted()
        {
            isCrafted = true;
        }
    }
}
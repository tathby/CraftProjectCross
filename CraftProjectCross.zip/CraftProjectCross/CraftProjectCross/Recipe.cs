﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CraftProjectCross
{
    public class Recipe
    {
        private String recipeName;
        private List<Item> itemsReq;
        private int numProd;
        private double recipeValue;

        public Recipe(String name, List<Item> req, int prod, double val)
        {
            recipeName = name;
            itemsReq = req;
            numProd = prod;
            recipeValue = val;
        }
    }
}
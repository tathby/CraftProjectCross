﻿using static CraftProjectCross.Library;

namespace CraftProjectCross
{
    public class Engine
    {
        private String appName = "CraftVersion1";
        public static Player user;
        private int itemList;
        private int recipeList;


        public static void Start()
        {
            user = new Player();
            user.ChangeName();
            user.About();
            Menu();
        }

        public static void Menu()
        {
            string ans = Input("\nWould you like to: \n1) Open your inventory\n2) View your recipes\n3) Enter the Shop\n4) Change your name\n5) Quit Game\n");

            switch (ans)
            {
                case "1":
                    //user.OpenInventory();
                    break;
                case "2":
                   // user.ViewRecipes();
                    break;
                case "3":
                    //Shop();
                    break;
                case "4":
                    user.ChangeName();
                    user.About();
                    break;
                case "5":
                    Environment.Exit(0);
                    break;
                default:
                    Console.WriteLine("Invalid choice. Please select a valid option.");
                    break;
            }
        }

        public void Shop()
        {
            
        }

    }
}